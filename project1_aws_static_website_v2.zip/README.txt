S3 Bucket URLs
http://udacityawsbucketexercisecmp.s3-website-us-east-1.amazonaws.com
http://udacityawsbucketexercisecmp.s3-website-us-east-1.amazonaws.com/index.html

Cloudfront URL
https://d1s3gk7oeqag4b.cloudfront.net/
