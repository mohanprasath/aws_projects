S3 Bucket URLs
http://udacityawsbucketexercisecmp.s3-website-us-east-1.amazonaws.com
http://udacityawsbucketexercisecmp.s3-website-us-east-1.amazonaws.com/index.html

Cloudfront URL
https://d2cdmj7chi1c5k.cloudfront.net/
